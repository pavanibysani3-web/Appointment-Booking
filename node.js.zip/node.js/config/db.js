const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    await mongoose.connect(
     "mongodb+srv://testUser:test123@cluster0.tvslnnf.mongodb.net/appointment_db?retryWrites=true&w=majority&appName=Cluster0"
    );

    console.log("MongoDB Connected");
  } catch (err) {
    console.log("DB Error:", err);
  }
};

module.exports = connectDB;