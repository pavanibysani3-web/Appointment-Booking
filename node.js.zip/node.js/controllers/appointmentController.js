const Appointment = require("../models/Appointment");

// CREATE
exports.createAppointment = async (req, res) => {
  try {
    const data = await Appointment.create(req.body);
    res.json(data);
  } catch (err) {
    res.status(500).json(err);
  }
};

// READ ALL
exports.getAppointments = async (req, res) => {
  try {
    const data = await Appointment.find();
    res.json(data);
  } catch (err) {
    res.status(500).json(err);
  }
};

// UPDATE
exports.updateAppointment = async (req, res) => {
  try {
    const data = await Appointment.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(data);
  } catch (err) {
    res.status(500).json(err);
  }
};

// DELETE
exports.deleteAppointment = async (req, res) => {
  try {
    await Appointment.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted Successfully" });
  } catch (err) {
    res.status(500).json(err);
  }
};