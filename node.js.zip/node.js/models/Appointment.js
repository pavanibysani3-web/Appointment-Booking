const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema({
  userEmail: String,
  doctorName: String,
  appointmentDate: String,
  appointmentTime: String,
  status: {
    type: String,
    default: "BOOKED"
  }
}, { timestamps: true });

module.exports = mongoose.model("Appointment", appointmentSchema);