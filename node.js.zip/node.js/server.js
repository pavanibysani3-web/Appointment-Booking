const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const appointmentRoutes = require("./routes/appointmentRoutes");

const app = express();

connectDB();

app.use(cors());
app.use(express.json());

app.use("/api/appointments", appointmentRoutes);
app.get("/insert", async (req, res) => {
  const Appointment = require("./models/Appointment");

  const data = await Appointment.create({
    userEmail: "test@gmail.com",
    doctorName: "Dr. Rao",
    appointmentDate: "2026-06-16",
    appointmentTime: "10:30 AM"
  });

  res.json(data);
});
app.listen(5001, () => {
  console.log("Server running on 5001");

});